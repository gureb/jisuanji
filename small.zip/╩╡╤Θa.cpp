#include<stdio.h>
#include<stdlib.h>
typedef struct date
{
	int year;
	short int month;
	short int day;
}date;
typedef struct customer
{
	char c_mkgsegment[11];
}customer;
typedef struct or
{
	int o_orderkey;
	int o_custkey;
    date c_orderdate;
}order;
typedef struct li
{
	int l_orderkey;
	float l_extendedprice;
	date l_shipdate;
}lineitem;
typedef struct re
{
	int custkey;
	int orderket;
	float price;
	char mkgsegment[11];
	date orderdate;
	date shipdate;
}result;
typedef struct find
{
	char mkgment[11];
	date order;
	date ship;
	int num;
}find;
customer cum[100];
order ord[16000];
lineitem lin[1000];
result res[1000];
find fin[100];
int cust()
{
	FILE *fp=NULL;
	char ch;
	int i=0,j=0,flag=0;
	//int k;
	fp=fopen("customer1.txt","r+");
	if(fp==NULL)
	{
		printf("��ʧ��");
		return 0;
	}
	ch=getc(fp);
	while(ch!=EOF)
	{
		if(ch=='|')
		{
			ch=getc(fp);
			flag=1;
		}
		if(ch=='\n')
		{i++;j=0;flag=0;ch=getc(fp);}
		if(flag==1)
		{
			cum[i].c_mkgsegment[j]=ch;
			j++;
		}
		ch=getc(fp);
	}
//	for(i=0;i<100;i++)
//	{
//		k=i+1;
//		printf("%d",k);
//		for(j=0;j<10;j++)
//		{
//			if(cum[i].c_mkgsegment[j]<'0')
//				break;
//			printf("%c",cum[i].c_mkgsegment[j]);
//		}
//		printf("\n");
//	}
	fclose(fp);	
	return 0;
}
int orde()
{
	FILE *fp=NULL;
	char ch;
	int a=0,b=0;
	int tag=0,flag=0,i=0,j=0,k=0,l=0;
	fp=fopen("order.txt","r+");
	if(fp==NULL)
	{
		printf("��ʧ��");
		return 0;
	}
	ord[i].o_orderkey=0;
	ord[i].c_orderdate.year=0;ord[i].c_orderdate.month=0;ord[i].c_orderdate.day=0;
	ch=getc(fp);
	while(ch!=EOF)
	{
		if(ch=='|')
		{
			if(flag==0)
				flag=1;
			else if(flag==1)
				flag=2;
			else 
				flag=0;
			ch=getc(fp);
		}
		if(ch=='\n')
		{
			i++;j=0;k=0;l=0;flag=0;tag=0;ch=getc(fp);ord[i].o_orderkey=0;
			ord[i].c_orderdate.year=0;ord[i].c_orderdate.month=0;ord[i].c_orderdate.day=0;
		}
		if(flag==0)
		{
			ord[i].o_orderkey=ch-'0'+ord[i].o_orderkey*10;
			k++;
		}
		else if(flag==1)
		{ 
			b=a*10;
			a=ch-'0';
			ord[i].o_custkey=a+b;
		}
	 	else if(flag==2)
		{
			if(ch=='-')
			{
			  if(tag==0)
				tag=1;
			  else if(tag==1)
				tag=2;
		      else 
				tag=0;
			  ch=getc(fp);
			}
			if(tag==0)
				ord[i].c_orderdate.year=ch-'0'+ord[i].c_orderdate.year*10;
			else if(tag==1)
				ord[i].c_orderdate.month=ch-'0'+ord[i].c_orderdate.month*10;
			else 
				ord[i].c_orderdate.day=ch-'0'+ord[i].c_orderdate.day*10;
		}
		ch=getc(fp);
	}
//	for(i=0;i<4000;i++)
//	{
//		printf("%d",ord[i].o_orderkey);
//		printf("-");
//		printf("%d",ord[i].o_custkey);
//		printf("-");
//		printf(" %d-%d-%d",ord[i].c_orderdate.year,ord[i].c_orderdate.month,ord[i].c_orderdate.day);
//		printf("\n");
//	}
	fclose(fp);	
	return 0;
}
int line()
{
	FILE *fp=NULL;
	char ch;
	float x;
	int flag=0,i=0,tag=0,j=0,k=1,z=0;
	fp=fopen("line.txt","r+");
	if(fp==NULL)
	{
		printf("��ʧ��");
		return 0;
	}
	lin[i].l_orderkey=0;
	lin[i].l_shipdate.year=0;lin[i].l_shipdate.month=0;lin[i].l_shipdate.day=0;
	ch=getc(fp);
	while(ch!=EOF)
	{
		if(ch=='|')
		{
			if(flag==0)
				flag=1;
			else if(flag==1)
				flag=2;
			else 
				flag=0;
			ch=getc(fp);
		}
		if(ch=='\n')
		{
			i++;j=0;tag=0;k=1;flag=0;ch=getc(fp);lin[i].l_orderkey=0;z=0;
			lin[i].l_shipdate.year=0;lin[i].l_shipdate.month=0;lin[i].l_shipdate.day=0;
		}
		if(flag==0)
		{
			lin[i].l_orderkey=ch-'0'+lin[i].l_orderkey*10;
		}
		else if(flag==1)
		{ 
			if(ch=='.')
			{
				z=1;
			    ch=getc(fp);
			}
			if(z==0)
			{
				x=ch-'0';
				lin[i].l_extendedprice=x+lin[i].l_extendedprice*10;
			}
			else
			{
				x=ch-'0';
				for(j=1;j<=k;j++)
					x=x*0.1;
				lin[i].l_extendedprice=lin[i].l_extendedprice+x;
				k++;
			}
		}
		else if(flag==2)
		{
			if(ch=='-')
			{
			  if(tag==0)
				tag=1;
			  else if(tag==1)
				tag=2;
		      else 
				tag=0;
			ch=getc(fp);
			}
			if(tag==0)
				lin[i].l_shipdate.year=ch-'0'+lin[i].l_shipdate.year*10;
			else if(tag==1)
				lin[i].l_shipdate.month=ch-'0'+lin[i].l_shipdate.month*10;
			else 
				lin[i].l_shipdate.day=ch-'0'+lin[i].l_shipdate.day*10;
		}
		ch=getc(fp);
	}
	ord[0].o_orderkey=1;
	ord[0].c_orderdate.year=1996;ord[0].c_orderdate.month=1;ord[0].c_orderdate.day=12;
//	for(i=0;i<1000;i++)
//	{
//		printf("%d",lin[i].l_orderkey);
//		printf("-");
//		printf("%.2f",lin[i].l_extendedprice);
//		printf("-");
//		printf("%d-%d-%d",lin[i].l_shipdate.year,lin[i].l_shipdate.month,lin[i].l_shipdate.day);
//		printf("\n");
//	}
	fclose(fp);	
	return 0;
}
int search(int x)
{
	int i;
	for(i=0;i<4000;i++)
	{
		if(ord[i].o_orderkey==x)
			return i;
		if(ord[i].o_orderkey>=x)
			break;
	}
	return(-1);
}
void connect()
{
	int i,j,z,k;
	for(i=0;i<1000;i++)
	{
		j=search(lin[i].l_orderkey);
		if(j==-1)
			continue;
		z=ord[j].o_custkey;
		if(z==0)
			continue;
		res[i].orderket=lin[i].l_orderkey;
		res[i].custkey=ord[j].o_custkey;
		res[i].price=lin[i].l_extendedprice;
		res[i].orderdate.year=ord[j].c_orderdate.year;
		res[i].orderdate.month=ord[j].c_orderdate.month;
		res[i].orderdate.day=ord[j].c_orderdate.day;
		res[i].shipdate.year=lin[i].l_shipdate.year;
		res[i].shipdate.month=lin[i].l_shipdate.month;
		res[i].shipdate.day=lin[i].l_shipdate.day;
		for(k=0;k<10;k++)
			res[i].mkgsegment[k]=cum[z-1].c_mkgsegment[k];
	}
}
int main()
{
	int i=0,j,k,a;
	int falg[1000];
	cust();
	orde();
	line();			
	connect();
	scanf("%d",&a);
	for(i=0;i<a;i++)
	{
		scanf("%s %d-%d-%d %d-%d-%d %d",&fin[i].mkgment,&fin[i].order.year,&fin[i].order.month,&fin[i].order.day,&fin[i].ship.year,&fin[i].ship.month,&fin[i].ship.day,&fin[i].num);
	}
    for(i=0;i<1000;i++)
	{
		for(j=0;j<8;j++)
		{
			if(j==7)
			{
				printf("%3d|%2d|%8.2f|",res[i].orderket,res[i].custkey,res[i].price);
				for(k=0;k<10;k++)
				{ 
				if(res[i].mkgsegment[k]<'0')
					break;
				printf("%c",res[i].mkgsegment[k]);}
				printf("\n");
		
			}
			if(fin[0].mkgment[j]==res[i].mkgsegment[j])
				continue;
			else break;
		}
	}
//	i=0;
//	printf("\n%s %d-%d-%d %d-%d-%d %d\n",fin[i].mkgment,fin[i].order.year,fin[i].order.month,fin[i].order.day,fin[i].ship.year,fin[i].ship.month,fin[i].ship.day,fin[i].num);
	//for(;i<1000;i++)
	//{
	//	if(res[i].orderket==0)
	//		continue;
	//	printf("%3d|%2d|%8.2f|",res[i].orderket,res[i].custkey,res[i].price);
	//	printf("%d-%2d-%2d|",res[i].orderdate.year,res[i].orderdate.month,res[i].orderdate.day);
	//	printf("%d-%2d-%2d|",res[i].shipdate.year,res[i].shipdate.month,res[i].shipdate.day);
	//	for(k=0;k<10;k++)
	//	{ 
	//		if(res[i].mkgsegment[k]<'0')
	//			break;
	//		printf("%c",res[i].mkgsegment[k]);}
	//	printf("\n");
	//}
	return 0;
}
